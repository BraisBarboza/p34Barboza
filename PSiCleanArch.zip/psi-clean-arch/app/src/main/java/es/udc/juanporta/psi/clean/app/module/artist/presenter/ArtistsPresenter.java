package es.udc.juanporta.psi.clean.app.module.artist.presenter;

public interface ArtistsPresenter {

    void initFlow();

    void onClickArtist();
}
